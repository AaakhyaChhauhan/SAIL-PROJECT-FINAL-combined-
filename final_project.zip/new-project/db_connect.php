<?php
$conn = new mysqli("sql12.freesqldatabase.com", "sql12791553", "B9Sva3lRQs", "sql12791553", 3306);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
